#
# Example file for HelloWorld
#

def main():
  print ("hello world!")
  l=5
  b=2
  print ("P=", 2*(l+b) )
    
if __name__ == "__main__":
  main()
