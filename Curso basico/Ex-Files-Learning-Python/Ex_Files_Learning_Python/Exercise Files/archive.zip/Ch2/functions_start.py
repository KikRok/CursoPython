
# Example file for working with functions
#

# define a basic function
def func1():
    print ("I am a function")

# function that takes arguments
def func2(arg1, arg2):
    print (arg1," ",arg2)

# function that returns a value


# function with default value for an argument


#function with variable number of arguments

func1()
print(func1())
print (func1)

func2(10,20)
print (func2(10,20))
print (cube(3))